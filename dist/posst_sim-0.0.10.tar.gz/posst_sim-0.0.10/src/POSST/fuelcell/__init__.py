# -*- coding: utf-8 -*-
r"""

# Fuel Cell Model

---

## Description
Subcategory of Fuel Cell Models.

---

## Models

### Stackmodel ZBT

- [Stackmodel 0.1]( https://zbt-tools.github.io/POSST/html/POSST/fuelcell/stack.html)
    
"""
