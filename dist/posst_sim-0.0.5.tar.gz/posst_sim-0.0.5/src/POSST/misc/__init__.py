# -*- coding: utf-8 -*-
r"""

# Gasmixture Models

---

## Description
Subcategory of Gasmixtures for Gasflows

---

## Models

### Mainmodels

- [Gas Mixture 0.1]( ./misc/Gas.html)

    
"""
